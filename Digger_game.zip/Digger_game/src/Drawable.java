
import java.awt.Graphics2D;

public interface Drawable {
	/**
	 * Draws the object to the specified graphics object.
	 *
	 * @param g
	 */
	void drawTo(Graphics2D g);
}