

import java.awt.geom.Point2D;

public interface Movable {
	/**
	 * @return the position of the object in its level's grid
	 */
	Coordinate getPosition();

	/**
	 * Moves to the specified coordinate.
	 *
	 * @param destination
	 */
	void moveTo(Coordinate destination);
}